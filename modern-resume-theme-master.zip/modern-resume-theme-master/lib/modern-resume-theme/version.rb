module ModernResumeTheme
  VERSION = "1.8.6"
end
